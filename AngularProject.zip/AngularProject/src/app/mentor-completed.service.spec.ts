import { TestBed } from '@angular/core/testing';

import { MentorCompletedService } from './mentor-completed.service';

describe('MentorCompletedService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorCompletedService = TestBed.get(MentorCompletedService);
    expect(service).toBeTruthy();
  });
});
