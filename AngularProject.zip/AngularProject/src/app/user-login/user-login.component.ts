import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import { ServiceService } from '../service.service';
import { Userregister } from '../user-signup/userregister';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

username:string;
password:string;
invalidLogin :boolean=false;
 userlogin:Userregister=new Userregister();
 private error=false;
  constructor(private router:Router,private service:ServiceService) { }

  ngOnInit() {
    
    
  }
  validate(){
    if(this.username==null || this.password==null){
      this.error=true;
      
    }
    
  else{
    this.error=false;
    this.service.getUser(this.username).subscribe(value=>this.userlogin=value);
    if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==1){
    
  this.router.navigate(['/usermenu',this.username]);
  this.invalidLogin = false;
    }
    else if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==3){
    
        this.router.navigate(['/mentormenu',this.username]);
        this.invalidLogin = false;
          }
          else  if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==2){
    
            this.router.navigate(['/adminmenu',this.username]);
            this.invalidLogin = false;
              }
          
else{
  this.invalidLogin=true;
}
    }
  }
  checkLogin() {
    (this.service.authenticate(this.username, this.password).subscribe(
      data => {
        this.router.navigate(['/usermenu',this.username])
        this.invalidLogin = false
      },
      error => {
        this.invalidLogin = true

      }
    )
    );

  }
  
  }

