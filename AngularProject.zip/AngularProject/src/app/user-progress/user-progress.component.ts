import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { UserService } from "./../user.service";
import { UserCompleted } from "./../user-completed";

@Component({
  selector: 'app-user-progress',
  templateUrl: './user-progress.component.html',
  styleUrls: ['./user-progress.component.css']
})
export class UserProgressComponent implements OnInit {
  userCompleted: UserCompleted=new UserCompleted();
  private technology=[];

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.getUserCompletedList().subscribe(value=>this.technology=value as String[]);
  }

}
