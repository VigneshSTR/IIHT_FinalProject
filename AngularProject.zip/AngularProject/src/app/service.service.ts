import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
export class User{
  constructor(
    public status:string,
     ) {}
  
}

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url:string="/assets/data.json";
  url1:string="/assets/value.json";
  url2:string="/assets/data2.json";
  private baseUrl = 'http://localhost:8080/api'; 
   
  constructor(private http:HttpClient) { }

  getUser(username:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/user/finduser/${username}`);  
  }

  authenticate(username, password) {
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    return this.http.get<User>('http://localhost:8070/authenticate',{headers}).pipe(
     map(
       userData => {
        sessionStorage.setItem('username',username);
        return userData;
       }
     )

    );
  }


isUserLoggedIn() {
  let user = sessionStorage.getItem('username')
  console.log(!(user === null))
  return !(user === null)
}

logOut() {
  sessionStorage.removeItem('username')
}
  }

  

