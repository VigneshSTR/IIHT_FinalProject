import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-landing',
  templateUrl: './mentor-landing.component.html',
  styleUrls: ['./mentor-landing.component.css']
})
export class MentorLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
