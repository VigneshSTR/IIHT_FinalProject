export class MentorCompleted{
    username:string;
    fees:Int16Array;
    technology:string;
    duration:Int16Array;
    id:Int16Array;
}