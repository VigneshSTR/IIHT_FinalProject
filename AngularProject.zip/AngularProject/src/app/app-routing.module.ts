import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';
import { HomeComponent } from './home/home.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';
import { ContactComponent } from './contact/contact.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { EditTechnologyComponent } from './edit-technology/edit-technology.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { LogoutComponent } from './logout/logout.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { MentorListComponent } from './mentor-list/mentor-list.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorProgressComponent } from './mentor-progress/mentor-progress.component';
import { PaymentsComponent } from './payments/payments.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { UserProgressComponent } from './user-progress/user-progress.component';
import { UserSignupComponent } from './user-signup/user-signup.component';

const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'user-login',component:UserLoginComponent },
    {path:'mentor-login',component:MentorLoginComponent},
    {path:'mentor-signup',component:MentorSignupComponent},
    {path:'admin-landing',component:AdminLandingComponent},
    {path:'contact',component:ContactComponent},
    {path:'edit-skills',component:EditSkillsComponent},
    {path:'edit-technology',component:EditTechnologyComponent},
    {path:'user-landing',component:UserLandingComponent},
    {path:'logout',component:LogoutComponent},
    {path:'mentor-completed',component:MentorCompletedComponent},
    {path:'mentor-landing',component:MentorLandingComponent},
    {path:'mentor-list',component:MentorListComponent},
    {path:'mentor-profile',component:MentorProfileComponent},
    {path:'mentor-progress',component:MentorProgressComponent},
    {path:'payments',component:PaymentsComponent},
    {path:'user-completed',component:UserCompletedComponent},
    {path:'user-progress',component:UserProgressComponent},
    {path:'user-signup',component:UserSignupComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
