import { Component, OnInit } from '@angular/core';
import { MentorService } from './../mentor.service';
import {Mentor} from './../mentor';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  mentor:Mentor=new Mentor();
  submitted=false;
  constructor(private mentorService:MentorService) { }

  ngOnInit() {
  }

  newMentor():void{
    this.submitted=false;
    this.mentor=new Mentor;
  }
  save(){
    this.mentorService.createMentor(this.mentor).subscribe(data=>console.log(data),error=>console.log(error));
    this.mentor=new Mentor();
  }
  onSubmit(){
    this.submitted=true;
    this.save();
  }
}
