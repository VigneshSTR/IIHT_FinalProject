import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserHeaderComponent } from './user-header/user-header.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';
import { ContactComponent } from './contact/contact.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { EditTechnologyComponent } from './edit-technology/edit-technology.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { LogoutComponent } from './logout/logout.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { MentorListComponent } from './mentor-list/mentor-list.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorProgressComponent } from './mentor-progress/mentor-progress.component';
import { PaymentsComponent } from './payments/payments.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { UserProgressComponent } from './user-progress/user-progress.component';
import {HttpClientModule} from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserLoginComponent,
    UserSignupComponent,
    UserHeaderComponent,
    MentorLoginComponent,
    MentorSignupComponent,
    AdminLandingComponent,
    ContactComponent,
    EditSkillsComponent,
    EditTechnologyComponent,
    UserLandingComponent,
    LogoutComponent,
    MentorCompletedComponent,
    MentorLandingComponent,
    MentorListComponent,
    MentorProfileComponent,
    MentorProgressComponent,
    PaymentsComponent,
    UserCompletedComponent,
    UserProgressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
