import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-progress',
  templateUrl: './mentor-progress.component.html',
  styleUrls: ['./mentor-progress.component.css']
})
export class MentorProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
