import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { UserService } from "./../user.service";
import { UserCompleted } from "./../user-completed";

@Component({
  selector: 'app-user-completed',
  templateUrl: './user-completed.component.html',
  styleUrls: ['./user-completed.component.css']
})
export class UserCompletedComponent implements OnInit {
  userCompleted: UserCompleted=new UserCompleted();
  private technology=[];

  constructor(private userService:UserService) { }

  ngOnInit() {
  this.userService.getUserCompletedList().subscribe(value=>this.technology=value as String[]);
  }
    

}
