export class UserCompleted 
{
    id : number;
    duration : string;
    technology : string; 
    fees:Int16Array;
    username:Username;
    completedduration:string;
    pendingduration:string;
    progress:Int16Array;
}
export class Username{
    username:string;
    password:string;
    role:Role;
}
export class Role{
    id:number;
    role:string;
}