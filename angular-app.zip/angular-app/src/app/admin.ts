export class Admin {
    username: string;
    contactnumber: Int16Array;
    firstname: String;
    lastname: String;
    password:string;
    confirmpassword:string;
    experience:Int16Array;
    facilities:String;
}